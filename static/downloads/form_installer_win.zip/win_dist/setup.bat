@echo off
echo ========================================
echo   Form Network - Automated Setup
echo ========================================
echo 1. Checking environment...
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Python not found! Please install Python 3.8+ to continue.
    pause
    exit /b
)
echo 2. Installing secure dependencies...
python -m pip install -r requirements.txt
echo 3. Initializing routing core...
python device_client/core/main.rs --setup
echo 4. Linking system to Form Cloud...
echo DONE.
echo ========================================
echo   Form is now ACTIVE on this machine.
echo ========================================
pause
